module.exports = {
    'Chris': [
        'chris',
        'christopher',
        'chris ortiz',
        'christopher ortiz',
        'topher',
        'runtmonk',
        'runt monk'
    ],
    'Doug': [
        'doug',
        'douglas',
        'doug forgione',
        'douglas forgione',
        'fouglas',
        'pinkie'
    ],
    'Greg': [
        'greg',
        'gregory',
        'greg pellizzi',
        'gregory pellizzi',
        'xavier'
    ],
    'Jen': [
        'jen',
        'jennifer',
        'jen alch',
        'jen ortiz',
        'jennifer alch',
        'jennifer ortiz',
        'hennifer',
        'hennifer lopez'
    ],
    'Kelly': [
        'kelly',
        'kelly yam',
        'kelly maher'
    ],
    'Marco': [
        'marco',
        'marco sansone',
        'marcoooo'
    ],
    'Marie': [
        'marie',
        'marie crasta',
        'missus crasta'
    ],
    'Michelle': [
        'michelle',
        'michelle pellizzi',
        'uchie'
    ],
    'Phil': [
        'phil',
        'phil yam',
        'phillup',
        'phillup yam',
        'phillium',
        'sweet potato'
    ],
    'Rohit': [
        'rohit',
        'rohit crasta',
        'roh'
    ],
    'Sal': [
        'sal',
        'sal saia',
        'salvatore',
        'salvatore saia'
    ],
    'Sam': [
        'sam',
        'samantha',
        'sam saia',
        'samantha saia',
        'sammy',
        'sammie'
    ],
    'Stefano': [
        'stefano',
        'stefano sansone',
        'stef'
    ],
    'Tony': [
        'tony',
        'anthony',
        'tony nac',
        'tony naclerio',
        'anthony naclerio',
        'mister nac',
        'mister naclerio'
    ]
};
