module.exports = {
    'Chris': {
        'address': 'same as Jen',
        'heritage': 'Fillipino',
        'birthday': 'September 23rd, 1990'
    },
    'Doug': {
        'address': '90 Yale Place, Rockville Centre NY 11570',
        'heritage': 'French... french, french french French!',
        'birthday': 'February 11th, 1990'
    },
    'Greg': {
        'address': 'someplace out by Northport',
        'heritage': 'Italian furnace',
        'birthday': 'December 23rd, 1989'
    },
    'Jen': {
        'address': 'same as Chris',
        'heritage': '... Huntingtinian',
        'birthday': 'March 23rd, 1991'
    },
    'Kelly': {
        'address': 'Astoria, apartment, 4F',
        'heritage': 'American?',
        'birthday': 'April 18th, 1992'
    },
    'Marco': {
        'address': 'ALABAMA',
        'heritage': 'F.O.B. Italian',
        'birthday': 'January 9th, 1990'
    },
    'Marie': {
        'address': '13 Lakeview Road, Wayland, Massachusetts 01778',
        'heritage': 'Rochestarian?',
        'birthday': 'May 25th, 1991'
    },
    'Michelle': {
        'address': 'someplace out by Northport',
        'heritage': 'European',
        'birthday': 'October 30th, 1992'
    },
    'Phil': {
        'address': 'Long Island City, apartment 4F',
        'heritage': 'Hong Kongian',
        'birthday': 'July 27th, 1990'
    },
    'Rohit': {
        'address': '13 Lakeview Road, Wayland, Massachusetts 01778',
        'heritage': 'Native American ... I mean Indian',
        'birthday': 'March 23rd, 1990'
    },
    'Sal': {
        'address': '49 Lee Ave, Rockville Centre NY 11570',
        'heritage': 'He claims to be Bohemian, but he\'s just Italian and an eastern Euro mutt',
        'phone': '516-754-3446',
        'email': 'salulos@gmail.com',
        'birthday': 'October 28th, 1990'
    },
    'Sam': {
        'address': '49 Lee Ave, Rockville Centre NY 11570',
        'heritage': 'Italian and proud of it',
        'birthday': 'October 6th, 1988'
    },
    'Stefano': {
        'address': '21 Hillside Avenue, Rockville Centre NY 11570',
        'heritage': 'Slightly less F.O.B. Italian than Marco',
        'birthday': 'February 23rd, 1992'
    },
    'Tony': {
        'address': '230 North Forest Avenue, Rockville Centre NY 11570',
        'heritage': 'Italion Stallion meatball-a-ball!',
        'birthday': 'January 14th, 1990'
    }
};
